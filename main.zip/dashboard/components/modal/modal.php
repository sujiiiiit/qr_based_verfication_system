<div class="modal-container">
    <div class="modal-dilog">
        <div class="modal-head">
            <span>
                <h2 class="h2">Generate</h2>
            </span>
            <button class="plain-btn" id="modal-close">
                <i class="btn-icon tgico-close"></i>
            </button>
        </div>
        <div class="modal-main">

        </div>
        <div class="modal-footer">
            <button id="btntogen" class="btn">Generate</button>
        </div>
    </div>
</div>